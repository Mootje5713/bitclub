<?php
echo "
<body style='background-color:lightblue'>
<center>
<h1>
Galgje
</h1>
<br>
<br>
<br>
<h2>
Je hebt gekozen om zelf een woord in te voeren
</h2>
<form action=/spel.php method=post>
<input type=text name=self> <br>
<input type=submit value='speel met dit woord' name=inleveren>
";

?>

